function On_Command(Player, Command, Args) 
{ 
	try
	{
		if (Command.Equals("info"))
		{
			var gameObject = Helper.GetLookObject(Player.PlayerClient.controllable.character.eyesRay, 300, -1);
			if (gameObject != undefined) 
			{
				Player.MessageFrom("INFO", "Object: " + gameObject.ToString()); 
			
				var structureMaster = gameObject.GetComponent("StructureMaster");
				var structureComponent = gameObject.GetComponent("StructureComponent");
				if (structureComponent != undefined)
				{
					structureMaster = structureComponent._master;
				}
				
				if (structureMaster != undefined) 
				{
					Player.MessageFrom("INFO", "Owner ID: " + structureMaster.ownerID.ToString());
				}

				var deployableObject = gameObject.GetComponent("DeployableObject");
				if (deployableObject != undefined) 
				{
					Player.MessageFrom("INFO", "Owner ID: " + deployableObject.ownerID.ToString());
				}

				var takeDamage = gameObject.GetComponent("TakeDamage");
				if (takeDamage != undefined) 
				{
					Player.MessageFrom("INFO", "TakeDamage: " + takeDamage.GetType().Name);
					if (takeDamage.GetType().Name == "ProtectionTakeDamage") 
					{
						Player.MessageFrom("INFO", "Protection"+
							": Generic=" + takeDamage.GetArmorValue(0)+
							", Bullet=" + takeDamage.GetArmorValue(1)+
							", Melee=" + takeDamage.GetArmorValue(2)+
							", Explosion=" + takeDamage.GetArmorValue(3)+
							", Radiation=" + takeDamage.GetArmorValue(4)+
							", Cold=" + takeDamage.GetArmorValue(5)
						);
					}
					Player.MessageFrom("INFO", "Health: " + takeDamage.health.ToString("F2") + " / " + takeDamage.maxHealth.ToString("F2"));
				}

				var resourceTarget = gameObject.GetComponent("ResourceTarget");
				if (resourceTarget != undefined) 
				{
					for (var resourceItem in resourceTarget.resourcesAvailable)
					{
						Player.MessageFrom("INFO", "Available Resource: " + resourceItem.AmountLeft() + " x " + resourceItem.ResourceItemName);
					}
				}				
			}			
		}	
	} 
	catch (error) { Plugin.Log("Command.Info", "Exception " + error.message + " on On_Command: " + error.description); }
}
