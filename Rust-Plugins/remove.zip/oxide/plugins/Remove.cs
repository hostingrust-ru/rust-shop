using System.Collections.Generic;
using System;
using System.Reflection;
using UnityEngine;

namespace Oxide.Plugins
{
    [Info("Remove", "Reneb", "3.0.15", ResourceId = 651)]
    class Remove : RustPlugin
    {
        static FieldInfo buildingPrivlidges;

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Oxide Hooks
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        void Loaded()
        {
            buildingPrivlidges = typeof(BasePlayer).GetField("buildingPrivlidges", (BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance | BindingFlags.NonPublic));
        }

        void OnServerInitialized()
        {
            InitializeTable();
            if (!permission.PermissionExists(normalPermission)) permission.RegisterPermission(normalPermission, this);
        }

        void Unload()
        {
            foreach (ToolRemover toolremover in Resources.FindObjectsOfTypeAll<ToolRemover>())
            {
                UnityEngine.Object.Destroy(toolremover);
            }
        }

        void OnHammerHit(BasePlayer player, HitInfo info)
        {
            if (player.GetComponent<ToolRemover>())
            {
                if (info.HitEntity.name.Contains("assets/prefabs/deployable") || info.HitEntity is BuildingBlock || info.HitEntity is SimpleBuildingBlock || info.HitEntity is Door)
                {
                    TryRemove(player, info.HitEntity);
                }
            }
        }

        private static Dictionary<string, string> displaynameToShortname = new Dictionary<string, string>();
        private static Dictionary<string, int> deployedToItem = new Dictionary<string, int>();
        private void InitializeTable()
        {
            displaynameToShortname.Clear();
            deployedToItem.Clear();
            List<ItemDefinition> ItemsDefinition = ItemManager.GetItemDefinitions() as List<ItemDefinition>;
            foreach (ItemDefinition itemdef in ItemsDefinition)
            {
                displaynameToShortname.Add(itemdef.displayName.english.ToString().ToLower(), itemdef.shortname.ToString());
                if (itemdef.GetComponent<ItemModDeployable>() != null) deployedToItem.Add(itemdef.GetComponent<ItemModDeployable>().entityPrefab.resourcePath, itemdef.itemid);
            }


        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Configs
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        protected override void LoadDefaultConfig() { }

        private void CheckCfg<T>(string Key, ref T var)
        {
            if (Config[Key] is T)
                var = (T)Config[Key];
            else
                Config[Key] = var;
        }

        static int RemoveTimeDefault = 30;
        static int MaxRemoveTime = 120;

        static int playerAuthLevel = 0;
        static string normalPermission = "removertool.canremove";

        static bool useToolCupboard = true;

        static bool useRefund = true;
        static bool refundDeployable = true;
        static bool refundStructure = true;
        static Dictionary<string, object> refundPercentage = defaultRefund();

        void Init()
        {

            CheckCfg("Remove - Default Time", ref RemoveTimeDefault);
            CheckCfg("Remove - Max Remove Time", ref MaxRemoveTime);
            if (MaxRemoveTime > 300)
            {
                Debug.Log("RemoverTool: Sorry but i won't let you use the Max Remove Time for longer then 300seconds");
                MaxRemoveTime = 300;
            }

            CheckCfg("Remove - Auth - AuthLevel - Normal Remove", ref playerAuthLevel);
            CheckCfg("Remove - Auth - Permission - Normal Remove", ref normalPermission);

            CheckCfg("Remove - Access - Use ToolCupboards", ref useToolCupboard);

            CheckCfg("Remove - Refund", ref useRefund);
            CheckCfg("Remove - Refund - Deployables", ref refundDeployable);
            CheckCfg("Remove - Refund - Structures", ref refundStructure);
            CheckCfg("Remove - Refund - Percentage (Structures Only)", ref refundPercentage);

            SaveConfig();
        }

        static Dictionary<string, object> defaultPay()
        {
            var dp = new Dictionary<string, object>();

            var dp0 = new Dictionary<string, object>();
            dp0.Add("wood", "1");
            dp.Add("0", dp0);

            var dp1 = new Dictionary<string, object>();
            dp1.Add("wood", "100");
            dp.Add("1", dp1);

            var dp2 = new Dictionary<string, object>();
            dp2.Add("wood", "100");
            dp2.Add("stones", "150");
            dp.Add("2", dp2);

            var dp3 = new Dictionary<string, object>();
            dp3.Add("wood", "100");
            dp3.Add("stones", "50");
            dp3.Add("metal fragments", "75");
            dp.Add("3", dp3);

            var dp4 = new Dictionary<string, object>();
            dp4.Add("wood", "250");
            dp4.Add("stones", "350");
            dp4.Add("metal fragments", "75");
            dp4.Add("high quality metal", "25");
            dp.Add("4", dp4);

            var dpdepoyable = new Dictionary<string, object>();
            dpdepoyable.Add("wood", "50");
            dp.Add("deployable", dpdepoyable);

            return dp;
        }

        static Dictionary<string, object> defaultRefund()
        {
            var dr = new Dictionary<string, object>();

            dr.Add("0", "100.0");
            dr.Add("1", "80.0");
            dr.Add("2", "60.0");
            dr.Add("3", "40.0");
            dr.Add("4", "20.0");

            return dr;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Random Functions
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        bool hasAccess(BasePlayer player, string permissionName, int minimumAuth)
        {
            if (player.net.connection.authLevel >= minimumAuth) return true;
            if (permission.UserHasPermission(player.userID.ToString(), permissionName)) return true;
            SendReply(player, "No Access");
            return false;
        }

        static void PrintToChat(BasePlayer player, string message)
        {
            player.SendConsoleCommand("chat.add", new object[] { 0, message, 1f });
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// class Tool Remover
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        class ToolRemover : MonoBehaviour
        {
            public BasePlayer player;
            public int endTime;
            public BasePlayer playerActivator;
            public float lastUpdate;

            void Awake()
            {
                player = GetComponent<BasePlayer>();
                lastUpdate = Time.realtimeSinceStartup;
            }

            public void RefreshDestroy()
            {
                Invoke("DoDestroy", endTime);
            }

            void DoDestroy()
            {
                Destroy(this);
            }

            void OnDestroy()
            {
                PrintToChat(player, "");
            }
        }
        void EndRemoverTool(BasePlayer player)
        {
            ToolRemover toolremover = player.GetComponent<ToolRemover>();
            if (toolremover == null) return;
            UnityEngine.Object.Destroy(toolremover);
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Remove functions
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        static void TryRemove(BasePlayer player, BaseEntity removeObject)
        {
            if (removeObject == null)
            {
                PrintToChat(player, "<color=red>Нечего удалять</color>");
                return;
            }
            var success = CanRemoveEntity(player, removeObject);
            if (success is string)
            {
                PrintToChat(player, (string)success);
                return;
            }
            if (useRefund)
                Refund(player, removeObject);
            DoRemove(removeObject);
        }

        static void DoRemove(BaseEntity removeObject)
        {
            if (removeObject == null) return;
            removeObject.KillMessage();
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Refund
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        static void Refund(BasePlayer player, BaseEntity entity)
        {
            if (refundDeployable && entity.GetComponentInParent<Deployable>() != null)
            {
                Deployable worlditem = entity.GetComponentInParent<Deployable>();
                if (deployedToItem.ContainsKey(worlditem.gameObject.name))
                    player.inventory.GiveItem(ItemManager.CreateByItemID(deployedToItem[worlditem.gameObject.name], 1, false));
            }
            else if (refundStructure && entity is BuildingBlock)
            {
                BuildingBlock buildingblock = entity as BuildingBlock;
                if (buildingblock.blockDefinition == null) return;

                int buildingblockGrade = (int)buildingblock.grade;
                if (buildingblock.blockDefinition.grades[buildingblockGrade] != null && refundPercentage.ContainsKey(buildingblockGrade.ToString()))
                {
                    decimal refundRate = decimal.Parse((string)refundPercentage[buildingblockGrade.ToString()]) / 100.0m;
                    List<ItemAmount> currentCost = buildingblock.blockDefinition.grades[buildingblockGrade].costToBuild as List<ItemAmount>;
                    foreach (ItemAmount ia in currentCost)
                    {
                        player.inventory.GiveItem(ItemManager.CreateByItemID(ia.itemid, Convert.ToInt32((decimal)ia.amount * refundRate), false));

                    }
                }
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Check Access
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        static bool hasTotalAccess(BasePlayer player)
        {
            List<BuildingPrivlidge> playerpriv = buildingPrivlidges.GetValue(player) as List<BuildingPrivlidge>;
            if (playerpriv.Count == 0)
            {
                return false;
            }
            foreach (BuildingPrivlidge priv in playerpriv.ToArray())
            {
                List<ProtoBuf.PlayerNameID> authorized = priv.authorizedPlayers;
                bool foundplayer = false;
                foreach (ProtoBuf.PlayerNameID pni in authorized.ToArray())
                {
                    if (pni.userid == player.userID)
                        foundplayer = true;
                }
                if (!foundplayer)
                {
                    return false;
                }
            }
            return true;
        }

        static object CanRemoveEntity(BasePlayer player, BaseEntity entity)
        {
            if (entity.isDestroyed) return "Entity is already destroyed";
            if (useToolCupboard)
                if (hasTotalAccess(player))
                    return true;

            return "<color=yellow>Вы должны быть авторизованы в Tool Cupboards</color>";
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// Chat Command
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        [ChatCommand("remove")]
        void cmdChatRemove(BasePlayer player, string command, string[] args)
        {
            int removeTime = RemoveTimeDefault;
            BasePlayer target = player;

            if (args.Length != 0)
            {
                switch (args[0])
                {
                    default:
                        if (!hasAccess(player, normalPermission, playerAuthLevel)) return;
                        int.TryParse(args[0], out removeTime);
                        break;
                }
            }
            if (removeTime > MaxRemoveTime) removeTime = MaxRemoveTime;

            ToolRemover toolremover = target.GetComponent<ToolRemover>();
            if (toolremover != null && args.Length == 0)

            {
                EndRemoverTool(player);
                PrintToChat(player, "<color=orange>Remover Tool выключен!</color>");
                return;
            }

            if (toolremover == null)
                toolremover = target.gameObject.AddComponent<ToolRemover>();
            PrintToChat(player, "<color=lime>Remover Tool активирован!</color> Для удаления используйте киянку!");

            toolremover.endTime = removeTime;
            toolremover.playerActivator = player;
            toolremover.RefreshDestroy();
        }
    }
}